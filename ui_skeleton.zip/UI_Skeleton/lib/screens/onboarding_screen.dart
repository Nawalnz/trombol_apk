import 'package:flutter/material.dart';

void main() {
  runApp(const CreateAcc());
}

class CreateAcc extends StatelessWidget {
  const CreateAcc({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      home: Scaffold(
        body: ListView(children: const [
          CreateAccount(),
        ]),
      ),
    );
  }
}

class CreateAccount extends StatelessWidget {
  const CreateAccount({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Column(
      children: [
        Container(
          width: size.width,  // Use the screen width
          height: size.height, // Use the screen height
          clipBehavior: Clip.antiAlias,
          decoration: const BoxDecoration(color: Colors.white),
          child: Stack(
            children: [
              Positioned(
                left: 26,
                top: 110,
                child: SizedBox(
                  width: size.width - 52, // Adjust width based on screen size
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Create account',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          letterSpacing: -0.17,
                        ),
                      ),
                      SizedBox(height: 5),
                      SizedBox(
                        width: 323,
                        child: Text(
                          'Get the best out of Paradise Trombol by creating an account',
                          style: TextStyle(
                            color: Color.fromRGBO(0, 0, 0, 0.8),
                            fontSize: 12,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            letterSpacing: -0.17,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Rest of your positioned widgets...
              Positioned(
                left: 26,
                top: 173,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width - 52, // Adjust width based on screen size
                      child: Column(
                        // Your form fields remain the same...
                        // Just ensure any fixed widths like "width: 323" are changed to be responsive
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Form fields...
                          // ... Your existing form fields code ...
                          // Just replace any fixed widths with responsive ones
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),
                    Container(
                      width: size.width - 52, // Make button width responsive
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17),
                      decoration: ShapeDecoration(
                        color: Color.fromRGBO(0, 0, 0, 0.2),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const [
                          Expanded(
                            child: Text(
                              'Create Account',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                height: 1.29,
                                letterSpacing: -0.17,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // Position the "Already have an account" text
              Positioned(
                bottom: 20, // Position from bottom instead of absolute top
                left: 0,
                right: 0,
                child: Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: 'Already have an account? ',
                        style: TextStyle(
                          color: Color.fromRGBO(0, 0, 0, 0.6),
                          fontSize: 10,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextSpan(
                        text: 'Go back',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 10,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}