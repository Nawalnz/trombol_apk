import 'package:flutter/material.dart';

void main() {
  runApp(const ForgetPwdApp());
}

class ForgetPwdApp extends StatelessWidget {
  const ForgetPwdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      home: const Scaffold(
        body: ForgotPasswordResetPassword(),
      ),
    );
  }
}

class ForgotPasswordResetPassword extends StatelessWidget {
  const ForgotPasswordResetPassword({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 50),
        decoration: const BoxDecoration(color: Colors.white),
        child: ListView(
          children: [
            // 🔙 Manual Back Arrow
            Align(
              alignment: Alignment.topLeft,
              child: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),

            const SizedBox(height: 10),

            // 🖼 Logo
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 103,
                  height: 102,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/trombol_logo_dark.png"),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            const Text(
              'Forget password',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                letterSpacing: -0.17,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'Enter your email or phone. We will send the verification code to reset your password.',
              style: TextStyle(
                color: Colors.black54,
                fontSize: 15,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
                letterSpacing: -0.17,
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              'Email',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 15,
                fontFamily: 'Poppins',
              ),
            ),

            const SizedBox(height: 10),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black),
                borderRadius: BorderRadius.circular(15),
              ),
              child: const TextField(
                decoration: InputDecoration(
                  hintText: 'melissa.ux@gmail.com',
                  border: InputBorder.none,
                ),
                style: TextStyle(
                  color: Colors.black38,
                  fontFamily: 'Poppins',
                  fontSize: 15,
                ),
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Reset with phone number',
              style: TextStyle(
                color: Color(0xFF0061D2),
                fontSize: 12,
                fontFamily: 'Poppins',
                decoration: TextDecoration.underline,
                decorationColor: Color(0xFF0060D2),
              ),
            ),

            const SizedBox(height: 40),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17),
              decoration: BoxDecoration(
                color: Color(0xD6042B55),
                borderRadius: BorderRadius.circular(15),
              ),
              child: const Center(
                child: Text(
                  'Request code',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    letterSpacing: -0.17,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
